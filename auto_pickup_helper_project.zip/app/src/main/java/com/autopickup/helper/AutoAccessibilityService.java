
package com.autopickup.helper;

import android.accessibilityservice.AccessibilityService;
import android.accessibilityservice.GestureDescription;
import android.graphics.Path;
import android.view.accessibility.AccessibilityEvent;

public class AutoAccessibilityService extends AccessibilityService {

    @Override
    public void onAccessibilityEvent(AccessibilityEvent event) {

        if(event.getEventType() == AccessibilityEvent.TYPE_VIEW_TEXT_CHANGED){

            if(event.getText() != null && event.getText().toString().length() > 5){
                click(900,1600); // posisi tombol OK (bisa diubah)
            }
        }
    }

    private void click(int x, int y){
        Path path = new Path();
        path.moveTo(x,y);

        GestureDescription.Builder builder = new GestureDescription.Builder();
        builder.addStroke(new GestureDescription.StrokeDescription(path,0,50));

        dispatchGesture(builder.build(),null,null);
    }

    @Override
    public void onInterrupt() {}
}
